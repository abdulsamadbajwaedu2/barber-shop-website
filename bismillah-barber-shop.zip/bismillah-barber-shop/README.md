# Bismillah Barber Shop Website
**Run:** open the folder in VS Code → install the *Live Server* extension → right-click `index.html` → *Open with Live Server*.

**Edit everything in `js/config.js`:** address, phone, WhatsApp (digits with country code, e.g. `923001234567`), opening hours, map embed URL, prices/services, team, testimonials, social links.

**Photos:** put files in `assets/images/` and set the path, e.g. `photo: "assets/images/talha.jpg"` (also `heroImage`, `aboutImage`, `ownerProfile.photo`, gallery `src`). Missing photos show a placeholder.

**Test booking:** click *Book This Service* → fill the form → *Review Request* → *Send via WhatsApp* (needs a valid number in config).

**Deploy (free):** drag the folder to Netlify Drop, or push to GitHub and enable GitHub Pages.
